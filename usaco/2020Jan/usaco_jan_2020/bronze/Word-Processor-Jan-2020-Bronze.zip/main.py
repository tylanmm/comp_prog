f = open("word.in")
data = f.readlines()
N = int(data[0].split()[0])
K = int(data[0].split()[1])
words = data[1].strip().split()
f.close()

f = open("word.out", "w")

wordIndex = 0
numCharsInLine = 0
currLine = ""

while True:
  currWord = words[wordIndex]

  if numCharsInLine + len(currWord) <= K:
    currLine += currWord + " "
    wordIndex += 1
    numCharsInLine += len(currWord)

    if wordIndex == len(words):
      # this means we have finished writing all of the words, so finish by writing the currLine without the trailing space
      currLine = currLine[:len(currLine)-1]
      f.write(currLine)
      break
  else:
    # this means we have to move onto the next line, so write the currLine but remove the trailing space
    currLine = currLine[:len(currLine)-1]
    f.write(currLine + "\n")

    # reset numCharsInLine, currLine
    numCharsInLine = 0
    currLine = ""

f.close()