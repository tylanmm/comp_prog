f = open("photo.in")
data = f.readlines()
N = int(data[0])
b = [int(x) for x in data[1].split()]

# the general idea is for each element in b, we try to break it into two numbers that sum to b_i. we test the first number in the finalList being 1, then 2, etc. until we find one that works

firstNum = 1
prevNum = 1
while True:
  finalList = []
  finalSet = set()
  prevNum = firstNum
  finalList.append(prevNum)

  for i in range(len(b)):
    nextNum = b[i]-prevNum
    
    # if the next possible number is 0 or negative, or if it's already in the list, then this sequence cannot work
    if nextNum < 1 or nextNum in finalSet:
      firstNum += 1
      break
    else:
      finalList.append(nextNum)
      finalSet.add(nextNum)
      prevNum = nextNum
    
  # if we reach here, then we have a working list!
  if len(finalList) == N:
    break

f = open("photo.out","w")
for i in range(len(finalList)-1):
  f.write(str(finalList[i]) + " ")
f.write(str(finalList[-1]))
f.close()