import math

f = open("race.in")
data = f.readlines()
K = int(data[0].split()[0])
N = int(data[0].split()[1])
queries = []
for i in range(1, len(data)):
  queries.append(int(data[i]))
f.close()

# in this problem, Bessie can essentially travel distances like this every second, accelerating to the end:
# 1m, 2m, 3m, 4m, 5m, etc. (CASE 1)
# the formula to sum the first n numbers is n*(n+1)/2
# this means we want to solve n*(n+1)/2 >= raceLength
# expressed in quadratic form, 1/2*n^2 + 1/2 - raceLength >= 0
# or, n^2 + 1 - 2*raceLength >= 0
# note that with rounding, the answer might be the positive root to this equation or that root+1, which we can check

# however, if her ending speed x_i has to be 3m, then the pattern has to look something like this:
# 1m, 2m, 3m, 4m, 3m (satisfying the constraints of X - this is CASE 2)
# notice that we could make this pattern 1, 2, ..., maxSpeed, maxSpeed-1, ... 2, 1 and modify the right side of the equation we are solving for
# the sum of these numbers would be 2*maxSpeed*(maxSpeed+1)/2, which we can simplify to maxSpeed*(maxSpeed+1)/2
# the extra sequence on the left side is then 1...X-1, so we need to add(X-1)*X/2 to the right side
# thus, we want to solve maxSpeed*(maxSpeed+1) >= raceLength + (X-1)*X/2
# expressed in quadratic form, maxSpeed^2 + maxSpeed - raceLength - (X-1)*X/2 >= 0
# or, maxSpeed^2 + maxSpeed - raceLength - X(X-1)/2 >= 0
# note that with rounding, we might have to add some number of seconds based on the positive solution to this quadratic, which we can check

def arithSum(maxNum):
  return int(maxNum * (maxNum+1) / 2);

def solveQuadratic(a,b,c):
  return (-b + math.sqrt(b * b - 4 * a * c)) / (2.0 * a);

f = open("race.out", "w")

for X in queries:
  # case 1 if the arithmetic sum from 1 to K >= raceLength
  if arithSum(X) >= K:
    root = solveQuadratic(1, 1, -2*K)
    answer = int(root)

    # check if we need to add one for rounding
    if arithSum(answer) >= K:
      f.write(str(answer) + "\n")
    else:
      f.write(str(answer+1) + "\n")

  # otherwise, we have case 2
  else:
    root = solveQuadratic(1, 1, -K-0.5*X*(X-1))
    topSpeed = int(root) # answer represents the top speed we reach

    # check if we need to add for rounding - just keeping adding more segments of (topSpeed+1)
    totalDist = 2*arithSum(topSpeed) - (X-1)*X/2
    totalTime = 2*topSpeed-(X-1)

    while totalDist < K:
      totalDist += topSpeed+1
      totalTime += 1

    f.write(str(totalTime) + "\n")
    
f.close()